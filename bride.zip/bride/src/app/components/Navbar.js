'use client'
import Link from 'next/link'
import React from 'react'
import Image from 'next/image';
import avatar from '../temp/avatar.png'
import { BsPerson } from 'react-icons/bs'

const style = {
    wrapper: 'h-18 w-full bg-blue-700 text-white flex md:justify-around items-center px-60 fixed z-[1000]',
    leftMenu: 'flex gap-4',
    logo: 'text-4xl text-white flex cursor-pointer mr-18',
    menuItem: 'text-lg text-white font-medium flex items-center mx-5 cursor-pointer',
    rightMenu: 'flex gap-4 items-center',

    loginButton: 'flex items-center cursor-pointer rounded-full hover:bg-[#333333] px-5 py-2',
    loginText: 'vml-3'
}


const loginAccount = '0xA1747351198Bec560f448DB46546E22B177e63b6'
//const loginAccount = ''

const Navbar = () => {

  return (
    <div className={style.wrapper}>
        <div className={style.leftMenu}>
            <div className={style.logo}><Link href='/'>Bride</Link> </div>
            <div className={style.menuItem}><Link href='/ride'>Ride</Link></div>
            <div className={style.menuItem}><Link href='/drive'>Drive</Link></div>
        </div>
        <div className={style.rightMenu}>        
                <div>
                    {loginAccount.slice(0, 6)} ... {loginAccount.slice(39)}
               </div>
        </div>
    </div>
  )
}

export default Navbar