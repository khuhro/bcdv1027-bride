'use client'
import { useEffect, useContext } from 'react';
import mapboxgl from 'mapbox-gl'

const style = {
    wrapper: 'flex-1',
    map:'w-full h-full 100vh'
    }
   
   //mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_ACCESS_TOKEN
   mapboxgl.accessToken = 'pk.eyJ1Ijoia2h1aHJvIiwiYSI6ImNsbGFiZjJkbjFqeXQzaXFqZmg5OWc1MzUifQ.CTuzO4tMC1j7UF4xrYor7A';

  // console.log(Object)

const Map = () => {
    useEffect(() => {
        const map = new mapboxgl.Map({
          container: 'map',
          style: 'mapbox://styles/drakosi/ckvcwq3rwdw4314o3i2ho8tph',
          center:[-79.38562, 43.67361],
          zoom: 5,
        })
    }, [])

  return (
    <div className={style.wrapper} >
      <div id='map' className={style.map} />
    </div>   
  )
}

export default Map