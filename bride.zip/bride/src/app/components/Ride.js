'use client'
import { useState, useEffect } from 'react';
import Image from 'next/image'
import avax_logo from '../assets/avax_logo.png'
import standard from '../assets/ridestypes/standard.png';
import luxury from '../assets/ridestypes/luxury.png';
import suv from '../assets/ridestypes/suv.png';


const query = `
*[_type=="rides"]{
  "service": title,
  "iconUrl": icon.asset->url,
  priceMultiplier,
  orderById
}|order(orderById asc)
`


const style = {
  wrapper: `h-full flex flex-col`,
  title: `text-gray-500 text-center text-xs py-2 border-b`,
  carList: `flex flex-col flex-1 overflow-scroll`,
  car: `flex p-3 m-2 items-center border-2 border-white`,
  selectedCar: `border-2 border-black flex p-3 m-2 items-center`,
  carImage: `h-14`,
  carDetails: `ml-2 flex-1`,
  service: `font-medium`,
  time: `text-xs text-blue-500`,
  priceContainer: `flex items-center`,
  price: `mr-[-0.8rem]`,
}

const basePrice = 1542;
const carList =[
  {
    service:'Standard',
    image: standard,
    priceMultiplier: 1
  },
  {
    service:'Luxury',
    image:luxury,
    priceMultiplier:155
  },
  {
    service:'SUV',
    image: suv,
    priceMultiplier: 1.8
  }
]

const Ride = () => {
  return (
    <div className={style.wrapper}>
      <div className={style.title}>Choose a ride, or swipe up for more</div>
      <div className={style.carList}>
        {carList.map((car, index) => (
          <div key={index} className= {style.car}>
            <Image
              src={car.iconUrl}
              className={style.carImage}
              height={50}
              width={50}
            />
            <div className={style.carDetails}>
              <div className={style.service}>{car.service}</div>
              <div className={style.time}>5 min away</div>
            </div>
            <div className={style.priceContainer}>
              <div className={style.price}>
                {((basePrice / 10 ** 5) * car.priceMultiplier).toFixed(5)}&nbsp;&nbsp;&nbsp;
              </div>
              <Image src={avax_logo} height={25} width={40} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Ride